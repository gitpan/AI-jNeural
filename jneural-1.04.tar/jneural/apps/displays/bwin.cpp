#include "bwin.h"
#include "nwin.h"

void bwin::wipe(int pause) {
    messages->wipe(pause);
}

void bwin::wipe() {
    messages->wipe();
}

void bwin::show_str(const char *s) { 
    messages->show_str(s);
}

void bwin::show_chr(chtype c, int x, int y) { 
    messages->show_chr(c, x, y);
}

void bwin::done_chr() {
    messages->done_chr();
}

bwin::bwin(WINDOW *win, int rs, int cs, int r, int c) {
    boxw     =   derwin(win,  rs,   cs,   r,   c);
    messages = new nwin(boxw, rs-2, cs-2, 1,   1);
    box(boxw, ACS_VLINE, ACS_HLINE);
    wrefresh(boxw);
}

bwin::~bwin() {
    delete messages;
    delwin(boxw);
}

