#ifndef D_WALKER_H
#define D_WALKER_H

#include <curses.h>
#include "nwin.h"
#include "bwin.h"

class walker_display {
    private:
        char msg[80];

        WINDOW *screen;

        bwin *messages;
        nwin *header;
        nwin *header2;
        nwin *scroller;
        nwin *escroller;
        nwin *dscroller;

        FILE *f;

        void show_header(char first_state, int states);
    public:
        walker_display(char first_state, int states);
        ~walker_display();

        void show_state(char first_state, char state);
        void show_epsilon(int yn);
        void show_action(int lr);
        void show_str(const char *s);
        void start_new_episode();
};

#endif
