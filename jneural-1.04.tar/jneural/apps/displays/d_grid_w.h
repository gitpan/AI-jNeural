#ifndef D_GRID_W_H
#define D_GRID_W_H

#include <curses.h>
#include "nwin.h"
#include "bwin.h"

class grid_w_display {
    private:
        char msg[80];

        WINDOW *screen;

        bwin *messages;
        bwin *map;

        nwin *escroller;
        nwin *wscroller;
        nwin *nscroller;

        int cx, cy;
        int sx, sy;
        int fx, fy;

        FILE *f;

    public:
        grid_w_display(int x, int y);
        ~grid_w_display();

        void show_state(int x, int y);
        void  set_start( int x, int y);
        void  set_finish(int x, int y);
        void show_str(const char *s);
        void show_num(double r);
        void start_new_episode();

        void show_epsilon( int yn);
        void show_wall_hit(int yn);
};

#endif
