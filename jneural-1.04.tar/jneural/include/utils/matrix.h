#ifndef MATRIX_H
#define MATRIX_H

#include <utils/real.h>

class matrix {
    private:
        real  *V;
        real **M;
        int rows;
        int cols;
        int size;

    public:
        matrix();
        void   add_element(real v);
        void   start_new_row();
        void   show_matrix_graphically();
        real  *query_matrix_as_vector();
        real **query_matrix_as_matrix();
        int    query_size();
        int    query_rows();
        int    query_cols();
};

#endif
