#ifndef TRANSFER_H
#define TRANSFER_H

#include <math.h>
#include <utils/real.h>

#define SUM     0
#define SIGMOID 1
#define BIPOLAR 2
#define JBIPOLR 3
#define ELLIOTT 4

real transfer(    real to_xfer, int type);
real transfer_dot(real to_xfer, int type);
void set_transfer_functions(int type, int num, ...);

#endif
