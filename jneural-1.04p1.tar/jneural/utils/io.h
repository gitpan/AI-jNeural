
int  jopen(char *);
void jprintf(const char *, ...);
void jerror_show(int, const char*);

void jclose();
void jnuke();
