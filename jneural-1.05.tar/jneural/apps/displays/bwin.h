#ifndef BWIN_H
#define BWIN_H

#include <curses.h>
#include "nwin.h"

class bwin {
    private:
        WINDOW *boxw;
        nwin   *messages;

    public:
        bwin(WINDOW *win, int rs, int cs, int r, int c);
        ~bwin();

        void show_str(const char *s);
        void show_chr(chtype c, int x, int y);
        void done_chr();
        void wipe();
        void wipe(int pause);
};

#endif
