#ifndef NWIN_H
#define NWIN_H

#include <curses.h>

class nwin {
    private:
        WINDOW *messages;
        int position;
        int lastline;

    public:
        nwin(WINDOW *win, int rs, int cs, int r, int c);
        ~nwin();

        void show_str(const char *s);
        void show_chr(chtype c, int x, int y);
        void done_chr();
        void wipe();
        void wipe(int pause);
};

#endif
