#include <stdio.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <utils/real.h>

void main (void) {
    real dM = DBL_MAX;
    real dm = DBL_MIN;
    real dz = 0.0;
    real d1 = 1.0;
    real cheese_whore;

    cheese_whore = dM * dz;
    printf("(no err) %g * %g = %g\n", dM, dz, cheese_whore);

    cheese_whore = dM * dM;
    printf("   (err) %g * %g = %g\n", dM, dM, cheese_whore);

    cheese_whore = dm * dm;
    printf("   (err) %g * %g = %g\n", dm, dm, cheese_whore);

    cheese_whore = dM / dz;
    printf("   (err) %g / %g = %g\n", dM, dz, cheese_whore);

    cheese_whore = dM / dm;
    printf("   (err) %g * %g = %g\n", dM, dm, cheese_whore);

    cheese_whore = dz / dm;
    printf("(no err) %g * %g = %g\n", dz, dm, cheese_whore);

    cheese_whore = dM + d1;
    printf("   (err) %g + %g = %g\n", dM, d1, cheese_whore);

    cheese_whore = -dM - d1;
    printf("   (err) %g - %g = %g\n", -dM, d1, cheese_whore);
}
