#ifndef NORMALIZER_H
#define NORMALIZER_H

#include <utils/real.h>

class normalizer {
    private:
        real min, max;
        real Min, Max;

    public:
        normalizer(real _min, real _max, real _Min, real _Max);

        real normalize(real  r);
        real denormalize(real  r);

        void normalize(real *r, int size);
        void denormalize(real *r, int size);
};

#endif
